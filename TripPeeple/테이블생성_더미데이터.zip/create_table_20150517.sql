/* �� ���̺� */
CREATE TABLE member (
   member_num NUMBER NOT NULL, /* �� �÷� */
   email VARCHAR2(50) NOT NULL, /* �� �÷�2 */
   password VARCHAR2(50) NOT NULL, /* �� �÷�3 */
   member_id VARCHAR2(50) NOT NULL, /* �� �÷�4 */
   like_country VARCHAR2(200) /* �� �÷�5 */
);

ALTER TABLE member
   ADD
      CONSTRAINT PK_member
      PRIMARY KEY (
         member_num
      );

/* �� ���̺�2 */
CREATE TABLE city (
   city_num NUMBER NOT NULL, /* �� �÷� */
   country_num NUMBER NOT NULL, /* �� �÷�3 */
   city_name VARCHAR2(50) NOT NULL /* �� �÷�2 */   
);

ALTER TABLE city
   ADD
      CONSTRAINT PK_city
      PRIMARY KEY (
         city_num
      );

/* �� ���̺�3 */
CREATE TABLE country (
   country_num NUMBER NOT NULL, /* �� �÷� */
   continent_num NUMBER NOT NULL, /* �� �÷�2 */
   price NUMBER NOT NULL, /* �� �÷�3 */
   distance NUMBER NOT NULL, /* �� �÷�6 */
   language VARCHAR2(50) NOT NULL, /* �� �÷�4 */
   country_name VARCHAR2(50) NOT NULL /* �� �÷�5 */
);

ALTER TABLE country
   ADD
      CONSTRAINT PK_country
      PRIMARY KEY (
         country_num
      );

/* �� ���̺�4 */
CREATE TABLE score (
   city_num NUMBER NOT NULL, /* �� �÷�3 */
   member_num NUMBER NOT NULL, /* �� �÷�4 */
   star NUMBER /* �� �÷�2 */
);

ALTER TABLE score
   ADD
      CONSTRAINT PK_score
      PRIMARY KEY (
         city_num,
         member_num
      );

/* �� ���̺�5 */
CREATE TABLE follow (
   follwer_num NUMBER NOT NULL, /* �� �÷�2 */
   follwing_num NUMBER NOT NULL /* �� �÷� */
);

ALTER TABLE follow
   ADD
      CONSTRAINT PK_follow
      PRIMARY KEY (
         follwer_num,
         follwing_num
      );

/* �� ���̺�6 */
CREATE TABLE continent (
   continent_num NUMBER NOT NULL, /* �� �÷� */
   continent_name VARCHAR2(50) NOT NULL /* �� �÷�2 */
);

ALTER TABLE continent
   ADD
      CONSTRAINT PK_continent
      PRIMARY KEY (
         continent_num
      );

/* �� ���̺�7 */
CREATE TABLE board (
   board_num NUMBER NOT NULL, /* �� �÷� */
   member_num NUMBER NOT NULL, /* �� �÷�5 */
   city_num NUMBER NOT NULL, /* �� �÷�2 */
   file_name VARCHAR2(50), /* �� �÷�9 */
   file_path VARCHAR2(500), /* �� �÷�6 */
   file_size VARCHAR2(50), /* �� �÷�7 */
   file_type VARCHAR2(10), /* �� �÷�8 */
   content VARCHAR2(500), /* �� �÷�10 */
   create_time DATE NOT NULL, /* �� �÷�11 */
   modify_time DATE NOT NULL, /* �� �÷�12 */
   likes NUMBER NOT NULL /* �� �÷�13 */
);

ALTER TABLE board
   ADD
      CONSTRAINT PK_board
      PRIMARY KEY (
         board_num
      );

/* �� ���̺�8 */
CREATE TABLE reply (
   reply_num NUMBER NOT NULL, /* �� �÷� */
   board_num NUMBER NOT NULL, /* �� �÷�2 */
   replyer_num NUMBER, /* �� �÷�3 */
   group_num NUMBER NOT NULL, /* �� �÷�4 */
   sequence_level NUMBER NOT NULL, /* �� �÷�5 */
   sequence_num NUMBER NOT NULL, /* �� �÷�6 */
   r_content VARCHAR2(500) NOT NULL, /* �� �÷�7 */
   create_time DATE NOT NULL, /* �� �÷�8 */
   modify_time DATE NOT NULL /* �� �÷�9 */
);

ALTER TABLE reply
   ADD
      CONSTRAINT PK_reply
      PRIMARY KEY (
         reply_num
      );

/* �� ���̺�9 */
CREATE TABLE follow (
);

ALTER TABLE city
   ADD
      CONSTRAINT FK_country_TO_city
      FOREIGN KEY (
         country_num
      )
      REFERENCES country (
         country_num
      );

ALTER TABLE country
   ADD
      CONSTRAINT FK_continent_TO_country
      FOREIGN KEY (
         continent_num
      )
      REFERENCES continent (
         continent_num
      );

ALTER TABLE score
   ADD
      CONSTRAINT FK_city_TO_score
      FOREIGN KEY (
         city_num
      )
      REFERENCES city (
         city_num
      );

ALTER TABLE score
   ADD
      CONSTRAINT FK_member_TO_score
      FOREIGN KEY (
         member_num
      )
      REFERENCES member (
         member_num
      );

ALTER TABLE follow
   ADD
      CONSTRAINT FK_member_TO_follow
      FOREIGN KEY (
         follwer_num
      )
      REFERENCES member (
         member_num
      );

ALTER TABLE follow
   ADD
      CONSTRAINT FK_member_TO_follow2
      FOREIGN KEY (
         follwing_num
      )
      REFERENCES member (
         member_num
      );

ALTER TABLE board
   ADD
      CONSTRAINT FK_city_TO_board
      FOREIGN KEY (
         city_num
      )
      REFERENCES city (
         city_num
      );

ALTER TABLE board
   ADD
      CONSTRAINT FK_member_TO_board
      FOREIGN KEY (
         member_num
      )
      REFERENCES member (
         member_num
      );

ALTER TABLE reply
   ADD
      CONSTRAINT FK_board_TO_reply
      FOREIGN KEY (
         board_num
      )
      REFERENCES board (
         board_num
      );

ALTER TABLE reply
   ADD
      CONSTRAINT FK_member_TO_reply
      FOREIGN KEY (
         replyer_num
      )
      REFERENCES member (
         member_num
      );