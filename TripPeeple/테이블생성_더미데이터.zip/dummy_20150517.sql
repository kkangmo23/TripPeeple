insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member10@trip.com',
'1234',
'member10',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member2@trip.com',
'1234',
'member2',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member3@trip.com',
'1234',
'member3',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member4@trip.com',
'1234',
'member4',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member5@trip.com',
'1234',
'member5',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member6@trip.com',
'1234',
'member6',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member7@trip.com',
'1234',
'member7',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member8@trip.com',
'1234',
'member8',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member9@trip.com',
'1234',
'member9',
null);

insert into member (member_num, email, password, member_id, like_country)
values(
MEMBER_NUM_SEQ.nextval,
'member10@trip.com',
'1234',
'member10',
null);

insert into continent (continent_num, continent_name)
values(
1,
'europe');

insert into continent (continent_num, continent_name)
values(
2,
'africa');

insert into continent (continent_num, continent_name)
values(
3,
'australia');

insert into continent (continent_num, continent_name)
values(
4,
'northamerica');

insert into continent (continent_num, continent_name)
values(
5,
'southamerica');

insert into continent (continent_num, continent_name)
values(
6,
'asia');


insert into country (country_num, continent_num, price, distance, language, country_name)
values(
1,
1,
3,
3,
'english',
'uk');

insert into country (country_num, continent_num, price, distance, language, country_name)
values(
2,
1,
3,
3,
'french',
'france');

insert into country (country_num, continent_num, price, distance, language, country_name)
values(
3,
1,
3,
3,
'spainish',
'spain');

insert into country (country_num, continent_num, price, distance, language, country_name)
values(
4,
2,
2,
3,
'english',
'rsa');

insert into country (country_num, continent_num, price, distance, language, country_name)
values(
5,
3,
3,
2,
'english',
'australia');

insert into country (country_num, continent_num, price, distance, language, country_name)
values(
6,
4,
3,
3,
'english',
'usa');

insert into country (country_num, continent_num, price, distance, language, country_name)
values(
7,
5,
2,
3,
'portugues',
'brasil');

insert into country (country_num, continent_num, price, distance, language, country_name)
values(
8,
6,
3,
1,
'japanese',
'japan');

insert into country (country_num, continent_num, price, distance, language, country_name)
values(
9,
6,
1,
1,
'lao',
'lao');


insert into city (city_num, country_num, city_name)
values (
1,
1,
'london');

insert into city (city_num, country_num, city_name)
values (
2,
2,
'paris');

insert into city (city_num, country_num, city_name)
values (
3,
3,
'barcelona');

insert into city (city_num, country_num, city_name)
values (
4,
5,
'sydney');

insert into city (city_num, country_num, city_name)
values (
5,
6,
'newyork');

insert into city (city_num, country_num, city_name)
values (
6,
6,
'la');

insert into city (city_num, country_num, city_name)
values (
7,
8,
'tokyo');

insert into city (city_num, country_num, city_name)
values (
8,
8,
'osaka');

insert into city (city_num, country_num, city_name)
values (
9,
9,
'vangvieng');

commit;

